# HairBloom Landing Page

เว็บไซต์ Landing Page ขายแชมพู (Demo) สำหรับงานข้อ 003

## สิ่งที่มีในโปรเจกต์
- สินค้า 3 SKU พร้อมข้อมูลตัวอย่าง
- หน้าแสดงสินค้าและราคา
- ตะกร้าสินค้าแบบจำลอง
- คำนวณยอดสินค้า + ค่าจัดส่งตัวอย่าง 40 บาท
- จำลองขั้นตอนตรวจสินค้า หยิบสินค้า แพ็กกล่อง และเตรียมส่ง
- โฟลเดอร์ `images/` แยกเก็บรูปสินค้า
- ข้อมูลตั้งต้นใน `data/products.csv`
- รองรับการอ่านข้อมูล Google Sheets แบบเผยแพร่ CSV

## เปิดเว็บไซต์ในเครื่อง
เปิด `index.html` ด้วย Chrome หรือ Firefox

## เชื่อม Google Sheets
1. สร้าง Google Sheet โดยใช้หัวตาราง: `SKU | Product Name | Thai Name | Description | Price | Image File`
2. เพิ่มข้อมูลสินค้าแต่ละแถว โดย `Image File` ใช้ path เช่น `images/apple.svg` หรือ URL รูปภาพสาธารณะ
3. ใน Google Sheets เลือก File > Share > Publish to web แล้วเลือกชีตสินค้าและรูปแบบ CSV จากนั้น Publish
4. คัดลอก URL CSV ที่ได้
5. เปิด `index.html` แล้วค้นหา `const SHEET_CSV_URL="";` ใส่ URL ภายในเครื่องหมายคำพูด
6. อัปโหลดโปรเจกต์ขึ้น GitHub และ Deploy ใหม่บน Vercel

หมายเหตุ: การดึง CSV ใช้ได้เมื่อชีตถูกเผยแพร่เป็นสาธารณะบนเว็บเท่านั้น อย่าใส่ข้อมูลส่วนบุคคลหรือข้อมูลลูกค้าจริงลงในชีตสาธารณะ

## GitHub
1. สร้าง repository ใหม่ เช่น `hairbloom-landing`
2. อัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้ โดยคงโครงสร้าง `images/` และ `data/`
3. Commit changes

## Vercel
1. เข้า Vercel แล้วเลือก Add New > Project
2. Import Git Repository ที่สร้างไว้
3. Framework Preset เลือก Other; Build Command และ Output Directory เว้นว่าง/ใช้ค่าเริ่มต้นสำหรับ static site
4. กด Deploy แล้วเปิด URL ที่ Vercel ให้มา

## ข้อจำกัดของ Demo
ไม่มีระบบชำระเงิน ฐานข้อมูลคำสั่งซื้อจริง หรือการเชื่อมบริษัทขนส่ง การแพ็กและสถานะพัสดุเป็นการจำลองเพื่อสาธิตงานเท่านั้น
